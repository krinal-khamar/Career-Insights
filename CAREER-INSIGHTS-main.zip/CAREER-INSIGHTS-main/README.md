# CAREER-INSIGHTS
A web Portal Used for the Prediction of Admission Jobs in Engineering and Technology /Management/Pharmacy with respect to demographic locations. 

#### Install and Run: 
--> cd Frontend <br>
--> npm install <br>
--> npm start <br> <br>

--> cd Backend <br>
--> npm install <br>
--> npm start <br>
